import React from "react";
import HorizontalNavbar from "../Header/HorizontalNavbar";

const NewNavbar = ({ setShowSidebar, showSidebar, open, setOpen }) => {
  return (
    <HorizontalNavbar />
  );
};

export default NewNavbar;
